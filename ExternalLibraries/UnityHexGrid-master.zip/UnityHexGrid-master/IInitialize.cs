﻿public interface IInitialize {
    void Init();
}
